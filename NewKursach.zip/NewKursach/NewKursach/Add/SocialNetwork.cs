﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewKursach.Add
{
    class SocialNetwork
    {
        public SocialNetwork(string url, string secretkey, int id)
        {
            this.Url = url;
            this.SecretKey = secretkey;
            this.Id = id;
        }

        public string Url { get; set; }
        public int Id { get; set; }
        public string SecretKey { get; set; }
    }
}
