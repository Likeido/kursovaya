﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VkNet;
using VkNet.Model;
using VkNet.Enums.Filters;
using Newtonsoft.Json;
using Leaf.xNet;
using System.IO;

namespace NewKursach.Add
{
    /// <summary>
    /// Логика взаимодействия для Autorization.xaml
    /// </summary>
    public partial class Autorization : Window
    {
        HttpRequest http = new HttpRequest();
        internal static VkApi vk = new VkApi();
        static string vkUri = $"https://oauth.vk.com/authorize?client_id=7391213&display=page&redirect_uri=https://oauth.vk.com/blank.html&scope=messages,offline&response_type=token&v=5.52";
        public Autorization() { 
            InitializeComponent();
            if (!vk.IsAuthorized)
            {
            GetToken.Source = new Uri(vkUri);
            }
        }
        private void WriteToken(Uri token)
        {
            
            if (token!=null)
            using (StreamWriter sw = new StreamWriter($"..\\..\\token.txt"))
            {
                    sw.WriteLine(token.ToString());
            }
        }

        private void authbutton_Click(object sender, RoutedEventArgs e)
        {
            
            
        }
    }
}
