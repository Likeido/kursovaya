﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VkNet;

namespace NewKursach.messages
{
    /// <summary>
    /// Логика взаимодействия для Messages.xaml
    /// </summary>
    public partial class Messages : Page
    {
        public Messages()
        {
            InitializeComponent();
            dialogs.DataContext = new Grid();
            messages.DataContext = new Grid();
        }

        private void search_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void reload_Click(object sender, RoutedEventArgs e)
        {
            if (!Add.Autorization.vk.IsAuthorized)
                MessageBox.Show("вы не вошли в профиль, нажмите на add");
        }
        private void GetDialogs()
        {
            
        }
    }
}
